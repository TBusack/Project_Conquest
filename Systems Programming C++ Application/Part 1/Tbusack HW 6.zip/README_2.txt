Cat.cpp is a program that creates a Cat object in C++ and runs various functions

To run this program on Windows, first ensure you have the proper compiler installed and have navigated to the right directory
Then type g++ -Wall test_cat.cpp Cat.cpp Animal.cpp -lm –o runCat

In the terminal, navigate to the directory where the compiled program is stored and input "runCat"

If you receive an error before running the program, you are likely in the wrong directory or did not properly compile the program.

If you receive and error while the program in running, the code may be incorrect or was improperly handled by your compiler
The files missing may not prompt an error and may run fine but fail to complete the task.

I completed this assignment alone