matrix_calc.c is a program that finds and prints
the sum/difference of two arrays of numbers taken
from two text files passed in via command line

To run this program on Windows, first ensure you have the proper compiler installed and have navigated to the right directory
Then type "make all"
If this fails, try "ming32w-make all"
In the terminal, navigate to the directory where the compiled program is stored and input "matrixCalc.exe" followed by the names of each file that
you want the program to read from with a single space in between each. Ensure that you capitalize properly and include the .txt extention
Finally, if you want it to find the sums, type a after the second file. For subtraction, type s
Now hit enter

If you receive an error before running the program, you are likely in the wrong directory or did not properly compile the program.

If you receive and error while the program in running, you likely did not have the input and output files available, or the data in them was something the computer was not expecting. 
The files missing may not prompt an error and may run fine but fail to complete the task.

You may also see an error message given by the program if the matricies are different sizes

I completed this assignment alone